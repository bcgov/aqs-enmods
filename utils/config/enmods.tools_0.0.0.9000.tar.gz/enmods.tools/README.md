
# enmods.tools

<!-- badges: start -->

[![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](https://opensource.org/license/apache-2-0)
<!--[![R-CMD-check](https://github.com/bcgov/bcdata/actions/workflows/R-CMD-check.yaml/badge.svg)](https://github.com/bcgov/bcdata/actions/workflows/R-CMD-check.yaml)
[![Codecov test
coverage](https://codecov.io/gh/bcgov/bcdata/branch/main/graph/badge.svg)](https://app.codecov.io/gh/bcgov/bcdata?branch=main)-->

<!-- badges: end -->

The goal of enmods.tools is to provide users with a collection of useful functions and tests to manage the BC Government's instance of Aquatic Informatics Samples. API tokens are required.

## Installation

You can install the development version of enmods.tools like so:

1. Get the tar.gz file (enmods.tools_0.0.0.9000.tar.gz) from GitHub or the EMAB Data Management Team

2. Install the tar.gz file using the following script

``` r

install.packages(paste0("C:/Users/SABHANDA/OneDrive - Government of BC/teamdocs/GitHub/aqs-api/utils/config/", "enmods.tools_0.0.0.9000.tar.gz"), repos = NULL, type = "source")

```

3. Bring in the relevant environment variables to run the scripts. These include API tokens and URLs, which can be stored safely in an .Renviron file, like so:

``` r

readRenviron(paste0("C:/Users/SABHANDA/OneDrive - Government of BC/teamdocs/GitHub/aqs-api", "/.Renviron"))

```

4. Set the "env" variable to "prod" or "test" based on the AQS environment you would like to modulate. If you want to switch the operating environment at any time, you can reset this environment variable, although that is not recommended.

``` r

env = "prod"
```

## Example

This is a basic example which shows you how to solve a common problem: setting up configuration for the PROD environment

``` r

## basic example code to setup a configuration for the PROD environment

library(enmods.tools)

load_aqs_tokens_urls()

# Delete all profiles
delete_all_profiles(env)

preprocessing_units_unitsgroups(env)
unit_groups <- import_files(env, "unit_groups")
unit_groups_post <- post_profiles(env, "unit_groups", unit_groups)
unit_groups_get <- get_profiles(env, "unit_groups")
units <- import_files(env, "units")
units_post <- post_profiles(env, "units", units)
units_get <- get_profiles(env, "units")

preprocessing_observed_properties(env)
observed_properties <- import_files(env, "observed_properties")
observed_properties_post <- post_profiles(env, "observed_properties", observed_properties)
observed_properties_check <- qa_qc_profile(env, "observed_properties")
observed_properties_get <- get_profiles(env, "observed_properties")

preprocessing_others(env)
result_grades <- import_files(env, "result_grades")
result_grades_put <- put_profiles(env, "result_grades", result_grades)
result_grades_get <- get_profiles(env, "result_grades")
result_statuses <- import_files(env, "result_statuses")
result_statuses_put <- put_profiles(env, "result_statuses", result_statuses)
result_statuses_get <- get_profiles(env, "result_statuses")

taxonomy_levels <- import_files(env, "taxonomy_levels")
taxonomy_levels_put <- put_profiles(env, "taxonomy_levels", taxonomy_levels)
taxonomy_levels_get <- get_profiles(env, "taxonomy_levels")
taxons <- import_files(env, "taxons")
taxons_post <- post_profiles(env, "fish_taxonomy", taxons)
taxons_get <- get_profiles(env, "fish_taxonomy")

mediums <- import_files(env, "mediums")
mediums_put <- put_profiles(env, "mediums", mediums)
mediums_get <- get_profiles(env, "mediums")

collection_methods <- import_files(env, "collection_methods")
collection_methods_post <- post_profiles(env, "collection_methods", collection_methods)
collection_methods_get <- get_profiles(env, "collection_methods")

analytical_groups <- import_files(env, "analytical_groups")
analytical_groups_post <- post_profiles(env, "analytical_groups", analytical_groups)
analytical_groups_check <- qa_qc_profile(env, "analytical_groups")
analytical_groups_get <- get_profiles(env, "analytical_groups")


extended_attributes <- import_files(env, "extended_attributes")
extended_attributes_post <- post_profiles(env, "extended_attributes", extended_attributes)
extended_attributes_get <- get_profiles(env, "extended_attributes")

sampling_agency_get <- get_profiles(env, "sampling_agency")

detection_conditions <- import_files(env, "detection_conditions")
detection_conditions_post <- post_profiles(env, "detection_conditions", detection_conditions)
detection_conditions_get <- get_profiles(env, "detection_conditions")

projects <- import_files(env, "projects")
projects_post <- post_profiles(env, "projects", projects)
projects_get <- get_profiles(env, "projects")

analysis_methods <- import_files(env, "analysis_methods")
analysis_methods_post <- post_profiles(env, "analysis_methods", analysis_methods)
analysis_methods_get <- get_profiles(env, "analysis_methods")

labs <- import_files(env, "labs")
labs_post <- post_profiles(env, "labs", labs)
labs_get <- get_profiles(env, "labs")

location_group_types <- import_files(env, "location_group_types")
location_group_types_put <- put_profiles(env, "location_group_types", location_group_types)
location_group_types_get <- get_profiles(env, "location_group_types")
location_types <- import_files(env, "location_types")
location_types_put <- put_profiles(env, "location_types", location_types)
location_types_get <- get_profiles(env, "location_types")

preprocessing_sampling_locations(env)
location_groups <- import_files(env, "location_groups")
location_groups_post <- post_profiles(env, "location_groups", location_groups)
location_groups_get <- get_profiles(env, "location_groups")

#Need to put locations in before putting in Saved Filters
locations_get <- get_profiles(env, "locations")
preprocessing_saved_filters(env)
saved_filters <- import_files(env, "saved_filters")
saved_filters_post <- post_profiles(env, "filters", saved_filters)
saved_filters_get <- get_profiles(env, "filters")
```

